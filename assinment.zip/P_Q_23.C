#include<stdio.h>
#include<conio.h>

void main()

{

  char i,j;
  int a=0,b=1;
  clrscr();

  for(i=1;i<=5;i++)
  {
	for(j=1;j<=i;j++)
	{
		if(j%2==0)
		{
			printf("%d",a);
		}
		else
		{
			printf("%d",b);
		}
	}
		printf("\n");
  }
  getch();
  }