#include<stdio.h>
#include<conio.h>

void main()
{

  int i,j,k,l;
  clrscr();

  for(i=1;i<=4;i++)
  {
	for(k=1;k<6-i;k++)
	{
		printf("  ");
	}
	for(j=1;j<=1;j++)
	{
		printf("*");
	}
	for(k=1;k<i;k++)
	{
		printf("    ");
	}
	for(j=1;j>=1;j--)
	{
		printf("*");
	}
	printf("\n");
  }
	getch();
  }